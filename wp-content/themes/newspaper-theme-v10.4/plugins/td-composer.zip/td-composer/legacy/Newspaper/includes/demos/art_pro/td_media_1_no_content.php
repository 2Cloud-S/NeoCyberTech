<?php
// ads
td_demo_media::add_image_to_media_gallery('td_reclama1',                   "http://demo_content.tagdiv.com/Newspaper_6/art_pro/reclama1.jpg");
td_demo_media::add_image_to_media_gallery('td_reclama2',                   "http://demo_content.tagdiv.com/Newspaper_6/art_pro/reclama2.jpg");
td_demo_media::add_image_to_media_gallery('td_reclama3',                   "http://demo_content.tagdiv.com/Newspaper_6/art_pro/reclama3.jpg");
