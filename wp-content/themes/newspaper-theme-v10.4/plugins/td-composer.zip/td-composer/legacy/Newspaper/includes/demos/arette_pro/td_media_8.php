<?php
td_demo_media::add_image_to_media_gallery('tdx_pic_10', 'https://cloud.tagdiv.com/demos/Newspaper/arette_pro/media/mobile-bg3.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_17', 'https://cloud.tagdiv.com/demos/Newspaper/arette_pro/media/member6.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_11', 'https://cloud.tagdiv.com/demos/Newspaper/arette_pro/media/login-bg.jpg');
