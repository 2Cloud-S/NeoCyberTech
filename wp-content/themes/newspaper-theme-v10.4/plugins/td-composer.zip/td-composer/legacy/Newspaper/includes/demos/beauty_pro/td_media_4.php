<?php
td_demo_media::add_image_to_media_gallery('td_pic_10', 'https://cloud.tagdiv.com/demos/Newspaper/beauty_pro/media/10.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_1', 'https://cloud.tagdiv.com/demos/Newspaper/beauty_pro/media/p1.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_2', 'https://cloud.tagdiv.com/demos/Newspaper/beauty_pro/media/p2.jpg');
