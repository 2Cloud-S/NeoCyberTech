<?php
td_demo_media::add_image_to_media_gallery('tdx_pic_6', 'https://cloud.tagdiv.com/demos/Newspaper/artist_pro/media/recbig.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_7', 'https://cloud.tagdiv.com/demos/Newspaper/artist_pro/media/artist.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_8', 'https://cloud.tagdiv.com/demos/Newspaper/artist_pro/media/5.jpg');
