<?php
td_demo_media::add_image_to_media_gallery('td_pic_4', 'https://cloud.tagdiv.com/demos/Newspaper/arette_pro/media/37.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_5', 'https://cloud.tagdiv.com/demos/Newspaper/arette_pro/media/36.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_6', 'https://cloud.tagdiv.com/demos/Newspaper/arette_pro/media/35.jpg');
