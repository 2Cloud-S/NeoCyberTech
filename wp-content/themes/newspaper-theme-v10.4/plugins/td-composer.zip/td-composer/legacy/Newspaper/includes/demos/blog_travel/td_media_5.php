<?php
td_demo_media::add_image_to_media_gallery('td_blog_travel_sidebar_ad',              "http://demo_content.tagdiv.com/Newspaper_6/blog_travel/banner-sidebar.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_travel',                   "http://demo_content.tagdiv.com/Newspaper_6/blog_travel/travel.png");
td_demo_media::add_image_to_media_gallery('td_pic_about',               "http://demo_content.tagdiv.com/Newspaper_6/blog_travel/about.jpg");