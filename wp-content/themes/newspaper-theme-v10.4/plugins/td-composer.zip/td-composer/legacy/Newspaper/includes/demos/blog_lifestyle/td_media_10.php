<?php
td_demo_media::add_image_to_media_gallery('td_pic_author_image',              "http://demo_content.tagdiv.com/Newspaper_6/blog_lifestyle/author-image.jpg");