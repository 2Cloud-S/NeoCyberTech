<?php
td_demo_media::add_image_to_media_gallery('tdx_pic_12', 'https://cloud.tagdiv.com/demos/Newspaper/arette_pro/media/member9.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_13', 'https://cloud.tagdiv.com/demos/Newspaper/arette_pro/media/member2.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_14', 'https://cloud.tagdiv.com/demos/Newspaper/arette_pro/media/member1.jpg');
