<?php
td_demo_media::add_image_to_media_gallery('td_pic_3',                   "http://demo_content.tagdiv.com/Newspaper_6/book_club/3.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_4',                   "http://demo_content.tagdiv.com/Newspaper_6/book_club/4.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_p3',                  "http://demo_content.tagdiv.com/Newspaper_6/book_club/p3.jpg");