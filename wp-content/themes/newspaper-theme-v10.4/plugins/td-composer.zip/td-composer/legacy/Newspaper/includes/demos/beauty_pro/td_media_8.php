<?php
td_demo_media::add_image_to_media_gallery('tdx_pic_14', 'https://cloud.tagdiv.com/demos/Newspaper/beauty_pro/media/homepage-background2.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_15', 'https://cloud.tagdiv.com/demos/Newspaper/beauty_pro/media/homepage-img4.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_16', 'https://cloud.tagdiv.com/demos/Newspaper/beauty_pro/media/reclama1.jpg');