<?php
td_demo_media::add_image_to_media_gallery('td_pic_7', 'https://cloud.tagdiv.com/demos/Newspaper/artist_pro/media/44.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_8', 'https://cloud.tagdiv.com/demos/Newspaper/artist_pro/media/43.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_9', 'https://cloud.tagdiv.com/demos/Newspaper/artist_pro/media/42.jpg');
