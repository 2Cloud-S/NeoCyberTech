<?php
td_demo_media::add_image_to_media_gallery('td_pic_7', 'https://cloud.tagdiv.com/demos/Newspaper/beauty_pro/media/7.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_8', 'https://cloud.tagdiv.com/demos/Newspaper/beauty_pro/media/8.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_9', 'https://cloud.tagdiv.com/demos/Newspaper/beauty_pro/media/9.jpg');
