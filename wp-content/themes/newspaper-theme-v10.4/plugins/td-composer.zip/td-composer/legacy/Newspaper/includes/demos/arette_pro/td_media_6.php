<?php
td_demo_media::add_image_to_media_gallery('tdx_pic_5', 'https://cloud.tagdiv.com/demos/Newspaper/arette_pro/media/reclama4.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_6', 'https://cloud.tagdiv.com/demos/Newspaper/arette_pro/media/background-asset7.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_16', 'https://cloud.tagdiv.com/demos/Newspaper/arette_pro/media/member8.jpg');

