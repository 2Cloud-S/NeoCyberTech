<?php
td_demo_media::add_image_to_media_gallery('tdx_pic_7', 'https://cloud.tagdiv.com/demos/Newspaper/arette_pro/media/reclama6.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_8', 'https://cloud.tagdiv.com/demos/Newspaper/arette_pro/media/pattern4.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_9', 'https://cloud.tagdiv.com/demos/Newspaper/arette_pro/media/reclama5.jpg');
